import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.Scanner;

public class Test {

	private static Scanner on;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
	     	// Caricamento del driver per MySQL
		//Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");

	      // Apertura di una connessione con il database
		
	      // creazione di uno statement sulla connessiona aperta
			
	      boolean ok = false;
	      while(!ok) {
	    	  Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/concessionariadef?user=root&password=benny2397&useSSL=false");
	           
		      // Print all warnings
		      for (SQLWarning warn = conn.getWarnings(); warn != null; 					warn= warn.getNextWarning()) 
			{
		      System.out.println("SQL Warning:");
		      System.out.println("State  : " + warn.getSQLState());
		      System.out.println("Message: " + warn.getMessage());
		      System.out.println("Error  : " + warn.getErrorCode());
		      }
		      Scanner in = new Scanner(System.in);
		      System.out.println("inserire il numero dell'operazione da effettuare (1-15), per uscire immettere un numero <1 o >15: ");
		      int OP = in.nextInt();
	    	  if((OP>=1)&& (OP<=15)) {
	    		  on = new Scanner(System.in);
			      if (OP==1) {
			    	  Statement stmtOP1 = conn.createStatement();
			    	  Statement stmtOP1S = conn.createStatement();
			    	  System.out.println("inserire TipoInOut:");
				      String TipoInOut = on.nextLine();
				      if(TipoInOut.equalsIgnoreCase("E")) {
				    	  System.out.println("inserire l'id del registro: ");
					      String idRegistro = on.nextLine();
					      System.out.println("inserire DataRegistrazione: ");
					      String DataRegistrazione = on.nextLine();
					      System.out.println("inserire l'id della Sede: ");
					      String idSede = on.nextLine();
					      System.out.println("inserire l'id del Cliente: ");
					      String idCliente = on.nextLine();
					      System.out.println("inserire il codice identificativo dell'Impiegato");
					      String CodiceIdentificativo = on.nextLine();
					      System.out.println("inserire il codice dell'operazione da effettuare (due lettere): ");
					      String CodiceOP = on.nextLine();
					      System.out.println("inserire il prezzo dell'operazione: ");
					      String Prezzo = on.nextLine();
					      System.out.println("inserire l'id del veicolo: ");
					      String idVeicolo = on.nextLine();
					      System.out.println("inserire il numero di serie: ");
					      String NumeroSerie = on.nextLine();
					      System.out.println("inserire i chilometri: ");
					      String Chilometri = on.nextLine();
					      System.out.println("insierire l'anno di fabbricazione: ");
					      String Anno = on.nextLine();
					      System.out.println("inserire il colore: ");
					      String Colore = on.nextLine();
					      System.out.println("inserire gli accessori: ");
					      String Accessori = on.nextLine();
					      System.out.println("inserire la marca: ");
					      String Marca = on.nextLine();
					      System.out.println("inserire il modello: ");
					      String Modello = on.nextLine();
					      System.out.println("inserire l'alimentazione: ");
					      String Alimentazione = on.nextLine();
					      System.out.println("inserire la targa: ");
					      String Targa = on.nextLine();
					      System.out.println("inserire la Destinazione d'uso (NV=nuova; US =usata; NL = Noleggiata; PV = Privata");
					      String DestinazioneUso = on.nextLine();
					      if(DestinazioneUso.equalsIgnoreCase("US")){
					    	  CodiceOP = "RV";
					      }
					      System.out.println("inserire l'id del motore: ");
					      String idMotore = on.nextLine();
					      System.out.println("inserire l'id del telaio: ");
					      String idTelaio = on.nextLine();
					      System.out.println("inserire l'id del possessore: ");
					      String idPossessore = on.nextLine();
					      String sql2 = "INSERT INTO `concessionariadef`.`registroin_out` (`idRegistroIN_OUT`, `TipoInOut`, `DataRegistrazione`, `Sede_idSede`, `Clienti_PIVA_CF`, `Impiegato_CodiceIdentificativo`, `CodiceOperazione`, `Prezzo`) VALUES ('"+idRegistro+"', '"+TipoInOut+"', '"+DataRegistrazione+"', '"+idSede+"', '"+idCliente+"', '"+CodiceIdentificativo+"', '"+CodiceOP+"', '"+Prezzo+"')";
					      stmtOP1S.executeUpdate(sql2);
					      String sql1 = "INSERT INTO `concessionariadef`.`auto` (`idVeicolo`, `NumeroSerie`, `Chilometri`, `Anno`, `Colore`, `Accessori`, `Marca`, `Modello`, `Alimentazione`, `Targa`, `DestinazioneUso`, `Motore_idMotore`, `Telaio_idTelaio`, `Possessore_PIVA_CF`, `RegistroIN_OUT_idRegistroIN_OUT`) VALUES ('"+idVeicolo+"', '"+NumeroSerie+"', '"+Chilometri+"', '"+Anno+"', '"+Colore+"', '"+Accessori+"', '"+Marca+"', '"+Modello+"', '"+Alimentazione+"', '"+Targa+"', '"+DestinazioneUso+"', '"+idMotore+"', '"+idTelaio+"', '"+idPossessore+"', '"+idRegistro+"')";
					      stmtOP1.executeUpdate(sql1); 
				          stmtOP1S.close();
				          stmtOP1.close();
				      }
				      if (TipoInOut.equalsIgnoreCase("O")) {
				    	  Statement stmtOP16 = conn.createStatement();
				    	  System.out.println("inserire id veicolo");
				    	  String V = on.nextLine();
				    	  ResultSet OP16 = stmtOP16.executeQuery("select R.* from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where A.idVeicolo = "+V+" and (R.TipoInOut = 'E' or R.TipoInOut = 'e')");
				    	  if(OP16.next()) {
					    	  if(OP16.getString(2).equalsIgnoreCase("E")) {
					    		  String idRegistro = OP16.getString(1);
					    		  //String DataR = OP16.getString(3);
					    		  String idSede = OP16.getString(4);
					    		  String Cliente = OP16.getString(5);
					    		  String Impiegato = OP16.getString(6);
					    		  //String CodiceOP = OP16.getString(7);
					    		  //String Prezzo = OP16.getString(8);
					    		  String sql16 = "UPDATE `concessionariadef`.`registroin_out` SET `TipoInOut`='O' WHERE `idRegistroIN_OUT`='"+idRegistro+"' and`Sede_idSede`='"+idSede+"' and`Clienti_PIVA_CF`='"+Cliente+"' and`Impiegato_CodiceIdentificativo`='"+Impiegato+"'";
					    		  stmtOP16.execute(sql16);
					    	  }
				    	  }
				    	  OP16.close();
			    		  stmtOP16.close();
				      }
			      }
			      else if (OP==2) {
			    	  Statement stmtOP2 = conn.createStatement();
			    	  String sql3 = "UPDATE `concessionariadef`.`auto` SET `Chilometri`='2395597', `Alimentazione`='GPL' WHERE `idVeicolo`='1' and`Motore_idMotore`='1' and`Telaio_idTelaio`='1' and`Possessore_PIVA_CF`='95555' and`RegistroIN_OUT_idRegistroIN_OUT`='7'";
				      stmtOP2.executeUpdate(sql3);
				      stmtOP2.close();
			      }
			      else if(OP==3) {
			    	  Statement stmtOP3 = conn.createStatement();
			    	  ResultSet OP3=stmtOP3.executeQuery("select Marca, Modello, idVeicolo from concessionariadef.auto");
			    	  while (OP3.next())
			 	         System.out.println(" OP3: "+ " Marca: "+ OP3.getString(1)+" Modello: "+OP3.getString(2)+" Codice: "+OP3.getString(3));
			    	  OP3.close();
			    	  stmtOP3.close();
			      }
			      else if (OP==4) {
			    	  Statement stmtOP4 = conn.createStatement();
			    	  System.out.println("inserire la data di inzio in formato DATEsql: ");
				      String DataI = on.nextLine();
				      System.out.println("inserire la data di fine in formato DATEsql: ");
				      String DataF = on.nextLine();
				      ResultSet OP4=stmtOP4.executeQuery("select A.* from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where R.TipoInOut = 'E' or R.TipoInOut = 'e' and R.DataRegistrazione between '"+DataI+"' and '"+DataF+"'");
				      while (OP4.next())
				    	  System.out.println(" OP4: "+"idVeicolo: "+ OP4.getString(1));
				      OP4.close();
				      stmtOP4.close();
			      }
			      else if (OP==5) {
			    	  Statement stmtOP5 = conn.createStatement();
			    	  ResultSet OP5=stmtOP5.executeQuery("select A.idVeicolo from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where R.TipoInOut = 'E' or R.TipoInOut = 'e'");
			    	  while (OP5.next())
				    	  System.out.println(" OP5: "+"idVeicolo: "+ OP5.getString(1));
			    	  OP5.close();
			    	  stmtOP5.close();
			      }
			      else if (OP==6) {
			    	  Statement stmtOP6 = conn.createStatement();
			    	  System.out.println("inserire la data per cui si vuole cercare in formato DATEsql: ");
				      String Data = on.nextLine();
				      ResultSet OP6=stmtOP6.executeQuery("select A.idVeicolo from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where R.DataRegistrazione = '"+Data+"'");
				      while (OP6.next())
					    	 System.out.println(" OP6: " +"idVeicolo: "+ OP6.getString(1));
				      OP6.close();
				      stmtOP6.close();
			      }
			      else if (OP==7) {
			    	  Statement stmtOP7 = conn.createStatement();
			    	  System.out.println("inserire la marca: ");
				      String Marca = on.nextLine();
				      ResultSet OP7=stmtOP7.executeQuery("select idVeicolo from concessionariadef.auto where Marca = '"+Marca+"'");
				      while (OP7.next())
				    	  System.out.println(" OP7: "+"idVeicolo: "+ OP7.getString(1));
				      OP7.close();
				      stmtOP7.close();
			      }
			      else if(OP==8) {
			    	  Statement stmtOP8 = conn.createStatement();
			    	  System.out.println("inserire la data di inzio in formato DATEsql: ");
				      String Data1 = on.nextLine();
				      System.out.println("inserire la data di fine in formato DATEsql: ");
				      String Data2 = on.nextLine();
				      ResultSet OP8=stmtOP8.executeQuery("select A.* from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where R.TipoInOut = 'E' or R.TipoInOut = 'e' and R.DataRegistrazione between '"+Data1+"' and '"+Data2+"'");
				      while (OP8.next())
				    	  System.out.println(" OP8: "+ "idVeicolo: "+ OP8.getString(1)+" Numero di serie: "+OP8.getString(2)+" Chilometri: "+OP8.getString(3)+" Anno: "+OP8.getString(4)+" Colore: "+OP8.getString(5)+" Accessori: "+OP8.getString(6)+ " Marca: "+OP8.getString(7)+" Modello: "+OP8.getString(8)+" Alimentazione: "+OP8.getString(9)+" Targa:"+OP8.getString(10)+" DestinazioneUso: "+OP8.getString(11)+" IDMotore: "+OP8.getString(12)+" IDTelaio: "+OP8.getString(13)+ " PIVA_CFPossessore"+OP8.getString(14)+" IdRegistroIN_OUT: "+OP8.getString(15));
				      OP8.close();
				      stmtOP8.close();
			      }
			      else if (OP==9) {
			    	  Statement stmtOP9 = conn.createStatement();
			    	  ResultSet OP9=stmtOP9.executeQuery("select sum(NumeroAuto) from concessionariadef.sede");
			    	  while (OP9.next())
				    	  System.out.println(" OP9: "+ "La concessionaria ha un numero di auto pari a: "+ OP9.getString(1));
			    	  OP9.close();
			    	  stmtOP9.close();
			      }
			      else if (OP==10) {
			    	  Statement stmtOP10 = conn.createStatement();
			    	  ResultSet OP10=stmtOP10.executeQuery("select T.* from (concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT) join concessionariadef.telaio T on A.Telaio_idTelaio = T.idTelaio where R.TipoInOut = 'E' or R.TipoInOut = 'e'");
			    	  while(OP10.next())
				    	  System.out.println(" OP10: " + " idTelaio: "+OP10.getString(1)+ " Data di costruzione: "+OP10.getString(2)+" Caratteristiche: "+OP10.getString(3));
			    	  OP10.close();
			    	  stmtOP10.close();
			      }
			      else if (OP==11) {
			    	  Statement stmtOP11 = conn.createStatement();
			    	  ResultSet OP11=stmtOP11.executeQuery("select M.* from (concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT) join concessionariadef.motore M on A.Motore_idMotore = M.idMotore where R.TipoInOut = 'E' or R.TipoInOut = 'e'");
			    	  while(OP11.next())
				    	  System.out.println(" OP11: " +" idMotore "+OP11.getString(1)+ " Cilindrata: "+OP11.getString(2)+" Alimentazione: "+OP11.getString(3)+ " DataCostruzione: "+OP11.getString(4));
			    	  OP11.close();
			    	  stmtOP11.close();
			      }
			      else if (OP==12) {
			    	  Statement stmtOP12 = conn.createStatement();
			    	  ResultSet OP12=stmtOP12.executeQuery("select A.* from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where (R.TipoInOut = 'O' or R.TipoInOut = 'O') and R.CodiceOperazione = 'NL' or R.CodiceOperazione = 'UA'");
			    	  while(OP12.next())
				    	  System.out.println(" OP12: " +"idVeicolo: "+ OP12.getString(1)+" Numero di serie: "+OP12.getString(2)+" Chilometri: "+OP12.getString(3)+" Anno: "+OP12.getString(4)+" Colore: "+OP12.getString(5)+" Accessori: "+OP12.getString(6)+ " Marca: "+OP12.getString(7)+" Modello: "+OP12.getString(8)+" Alimentazione: "+OP12.getString(9)+" Targa:"+OP12.getString(10)+" DestinazioneUso: "+OP12.getString(11)+" IDMotore: "+OP12.getString(12)+" IDTelaio: "+OP12.getString(13)+ " PIVA_CFPossessore"+OP12.getString(14)+"IdRegistroIN_OUT: "+OP12.getString(15));
			    	  OP12.close();
			    	  stmtOP12.close();
			      }
			      else if (OP==13) {
			    	  Statement stmtOP13 = conn.createStatement();
			    	  ResultSet OP13=stmtOP13.executeQuery("select A.*, R.Prezzo, R.CodiceOperazione, R.DataRegistrazione, CL.PIVA_CF, CL.Nome, CL.Cognome, I.CodiceIdentificativo, I.Nome, I.Cognome, I.PIVA_CF from ((concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT) join concessionariadef.clienti CL on R.Clienti_PIVA_CF = CL.PIVA_CF ) join concessionariadef.impiegato I on R.Impiegato_CodiceIdentificativo = I.CodiceIdentificativo where  R.CodiceOperazione = 'RI' or R.CodiceOperazione = 'CR' or R.CodiceOperazione = 'RV' or R.CodiceOperazione = 'CV'");
			    	  while(OP13.next())
				    	  System.out.println(" OP13: "+"idVeicolo: "+ OP13.getString(1)+" Numero di serie: "+OP13.getString(2)+" Chilometri: "+OP13.getString(3)+" Anno: "+OP13.getString(4)+" Colore: "+OP13.getString(5)+" Accessori: "+OP13.getString(6)+ " Marca: "+OP13.getString(7)+" Modello: "+OP13.getString(8)+" Alimentazione: "+OP13.getString(9)+" Targa:"+OP13.getString(10)+" DestinazioneUso: "+OP13.getString(11)+" IDMotore: "+OP13.getString(12)+" IDTelaio: "+OP13.getString(13)+ " PIVA_CFPossessore"+OP13.getString(14)+ " IdRegistroIN_OUT: "+OP13.getString(15) + " Prezzo: "+OP13.getString(16)+" DataRegistrazione: "+OP13.getString(17)+ " PIVA_CFcliente: "+OP13.getString(18)+" Nome del cliente: "+OP13.getString(19)+" Cognome del cliente: "+OP13.getString(20)+" CodiceIdentificativo dell'impiegato: "+OP13.getString(21)+" Nome dell'impiegato: "+OP13.getString(22)+" Cognome dell'impiegato: "+OP13.getString(23)+" PIVA_CF: "+OP13.getString(24));
			    	  OP13.close();
			    	  stmtOP13.close();
			      }
			      else if (OP==14) {
			    	  Statement stmtOP14 = conn.createStatement();
				      ResultSet OP14=stmtOP14.executeQuery("select A.* from concessionariadef.auto A join concessionariadef.registroin_out R on A.RegistroIN_OUT_idRegistroIN_OUT = R.idRegistroIN_OUT where R.TipoInOut = 'E' or R.TipoInOut = 'e' and A.DestinazioneUso = 'US' or A.DestinazioneUso = 'us'");
				      while(OP14.next())
				    	  System.out.println(" OP14: "+ "idVeicolo: "+ OP14.getString(1)+" Numero di serie: "+OP14.getString(2)+" Chilometri: "+OP14.getString(3)+" Anno: "+OP14.getString(4)+" Colore: "+OP14.getString(5)+" Accessori: "+OP14.getString(6)+ " Marca: "+OP14.getString(7)+" Modello: "+OP14.getString(8)+" Alimentazione: "+OP14.getString(9)+" Targa:"+OP14.getString(10)+" DestinazioneUso: "+OP14.getString(11)+" IDMotore: "+OP14.getString(12)+" IDTelaio: "+OP14.getString(13)+ " PIVA_CFPossessore"+OP14.getString(14)+" IdRegistroIN_OUT: "+OP14.getString(15));
				      OP14.close();
				      stmtOP14.close();
			      }
			      else if (OP==15) {
			    	  Statement stmtOP15 = conn.createStatement();
				      ResultSet OP15=stmtOP15.executeQuery("SELECT * FROM concessionaria.impiegato");
				      while(OP15.next())
				    	  System.out.println(" OP15: "+" CodiceIdentificativo impiegato: "+OP15.getString(1)+" PIVA_CF: "+OP15.getString(2)+" Nome: "+OP15.getString(3)+" Cognome: "+OP15.getString(3)+" email: "+OP15.getString(4)+" telefono: "+OP15.getString(5)+" Via:"+OP15.getString(6)+" Citt�: "+OP15.getString(7)+" Provinvia: "+OP15.getString(8)+" Stato: "+OP15.getString(9)+" Mansione: "+OP15.getString(10)+" et�: "+OP15.getString(11)+" DataAssunzione: "+OP15.getString(12)+" DataFineRapporto: "+OP15.getString(13)+" idSede: "+OP15.getString(14));
				      OP15.close();
				      stmtOP15.close();
			      }
			      
	      }
	    	  
	    	  if((OP>15) || (OP<1)) {
	    		  ok = true;
	    		  conn.close();
			      in.close();
	    	  }
	      }

	      
	      // Gestione del risultato della query

	      // Chiusura di result set, statement e connessione
	            
	            
	            System.out.println("programma terminato");
	      } catch (SQLException se) {
	        System.out.println("SQL Exception:");

	      // Verifica delle eventuali eccezioni SQL
	      while (se != null) {
	        System.out.println("State  : " + se.getSQLState());
	        System.out.println("Message: " + se.getMessage());
	        System.out.println("Error  : " + se.getErrorCode());

	        se = se.getNextException();
	        }
	      } catch (Exception e) {
	            System.out.println(e);
	     }
	   }

	}


