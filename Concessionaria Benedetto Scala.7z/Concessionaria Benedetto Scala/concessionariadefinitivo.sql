CREATE SCHEMA `concessionariadef` DEFAULT CHARACTER SET utf8 ;
USE `concessionariadef` ;

CREATE TABLE `Sede` (
  `idSede` int(11) NOT NULL AUTO_INCREMENT,
  `Denominazione` varchar(45) NOT NULL,
  `Via` varchar(45) DEFAULT NULL,
  `Città` varchar(45) DEFAULT NULL,
  `Provincia` char(2) DEFAULT NULL,
  `Telefono` int(11) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `Padiglione` varchar(45) DEFAULT NULL,
  `NumeroAuto` int(11) DEFAULT NULL,
  PRIMARY KEY (`idSede`)
) ENGINE=InnoDB;



CREATE TABLE `clienti` (
  `PIVA_CF` varchar(16) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Cognome` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefono` double DEFAULT NULL,
  `Via` varchar(45) DEFAULT NULL,
  `Città` varchar(45) DEFAULT NULL,
  `Provincia` char(2) DEFAULT NULL,
  `Stato` char(2) DEFAULT NULL,
  PRIMARY KEY (`PIVA_CF`)
) ENGINE=InnoDB;


CREATE TABLE `motore` (
  `idMotore` varchar(20) NOT NULL,
  `Cilindrata` varchar(45) DEFAULT NULL,
  `Alimentazione` varchar(10) DEFAULT NULL,
  `DataCostruzione` date DEFAULT NULL,
  PRIMARY KEY (`idMotore`)
) ENGINE=InnoDB;



CREATE TABLE `telaio` (
  `idTelaio` varchar(20) NOT NULL,
  `DataCostruzione` varchar(45) DEFAULT NULL,
  `Caratteristiche` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idTelaio`)
) ENGINE=InnoDB;



CREATE TABLE `possessore` (
  `PIVA_CF` varchar(16) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Cognome` varchar(45) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `telefono` double DEFAULT NULL,
  `Via` varchar(45) DEFAULT NULL,
  `Città` varchar(45) DEFAULT NULL,
  `Provincia` char(2) DEFAULT NULL,
  `Stato` char(2) DEFAULT NULL,
  PRIMARY KEY (`PIVA_CF`)
) ENGINE=InnoDB;



CREATE TABLE `impiegato` (
  `CodiceIdentificativo` varchar(45) NOT NULL,
  `PIVA_CF` varchar(16) NOT NULL,
  `Nome` varchar(45) NOT NULL,
  `Cognome` varchar(45) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `telefono` double DEFAULT NULL,
  `Via` varchar(45) DEFAULT NULL,
  `Città` varchar(45) DEFAULT NULL,
  `Provincia` char(2) DEFAULT NULL,
  `Stato` char(2) DEFAULT NULL,
  `Mansione` varchar(2) DEFAULT NULL COMMENT 'MC=Meccanico,IU=Impiegato d''Uffico,VD=Addetto alle Vendite',
  `età` int(2) DEFAULT NULL,
  `DataAssunzione` date DEFAULT NULL,
  `DataFineRapporto` date DEFAULT NULL,
  `Stipendio` double DEFAULT NULL,
  `Ferie` int(11) DEFAULT NULL COMMENT 'Espresse in giorni',
  `Sede_idSede` int(11) NOT NULL,
  PRIMARY KEY (`CodiceIdentificativo`,`Sede_idSede`),
  KEY `fk_Impiegato_Sede1_idx` (`Sede_idSede`),
  CONSTRAINT `fk_Impiegato_Sede1` FOREIGN KEY (`Sede_idSede`) REFERENCES `sede` (`idSede`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB;






CREATE TABLE `registroin_out` (
  `idRegistroIN_OUT` int(11) NOT NULL AUTO_INCREMENT,
  `TipoInOut` char(1) DEFAULT NULL COMMENT 'E=Entarta,U)=Uscita',
  `DataRegistrazione` date DEFAULT NULL,
  `Sede_idSede` int(11) NOT NULL,
  `Clienti_PIVA_CF` varchar(16) NOT NULL,
  `Impiegato_CodiceIdentificativo` varchar(45) NOT NULL,
  `CodiceOperazione` char(2) DEFAULT NULL COMMENT 'AQ=Acquisto,VN=Vendita,RT=Ritiro auto venduta,RI=Entrata per riparazione,RV=Entrata per revisione o tagliando,CR=Uscita auto riparata,CV=Consegna auto revisionata, NL = Noleggio, UA= Uscita auto acquistata nuova, UN = Uscita auto noleggiata; UU = Uscita auto acquistata usata',
  `Prezzo` int(9) DEFAULT NULL,
  PRIMARY KEY (`idRegistroIN_OUT`,`Sede_idSede`,`Clienti_PIVA_CF`,`Impiegato_CodiceIdentificativo`),
  KEY `fk_RegistroIN_OUT_Sede1_idx` (`Sede_idSede`),
  KEY `fk_RegistroIN_OUT_Clienti1_idx` (`Clienti_PIVA_CF`),
  KEY `fk_RegistroIN_OUT_Impiegato1_idx` (`Impiegato_CodiceIdentificativo`),
  CONSTRAINT `fk_RegistroIN_OUT_Clienti1` FOREIGN KEY (`Clienti_PIVA_CF`) REFERENCES `clienti` (`PIVA_CF`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_RegistroIN_OUT_Impiegato1` FOREIGN KEY (`Impiegato_CodiceIdentificativo`) REFERENCES `impiegato` (`CodiceIdentificativo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_RegistroIN_OUT_Sede1` FOREIGN KEY (`Sede_idSede`) REFERENCES `sede` (`idSede`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB;



CREATE TABLE `auto` (
  `idVeicolo` varchar(20) NOT NULL,
  `NumeroSerie` int(11) DEFAULT NULL,
  `Chilometri` double DEFAULT NULL,
  `Anno` int(4) DEFAULT NULL,
  `Colore` varchar(45) DEFAULT NULL,
  `Accessori` varchar(100) DEFAULT NULL,
  `Marca` varchar(20) DEFAULT NULL,
  `Modello` varchar(20) DEFAULT NULL,
  `Alimentazione` varchar(3) DEFAULT NULL COMMENT 'B,D,TB,TD,TDI,M,GPL',
  `Targa` varchar(10) DEFAULT NULL,
  `DestinazioneUso` char(2) DEFAULT NULL COMMENT 'NV=Nuova,NL=Noleggio, US=Usata, PV=Privata',
  `Motore_idMotore` varchar(20) NOT NULL,
  `Telaio_idTelaio` varchar(20) NOT NULL,
  `Possessore_PIVA_CF` varchar(16) NOT NULL,
  `RegistroIN_OUT_idRegistroIN_OUT` int(11) NOT NULL,
  PRIMARY KEY (`idVeicolo`,`Motore_idMotore`,`Telaio_idTelaio`,`Possessore_PIVA_CF`,`RegistroIN_OUT_idRegistroIN_OUT`),
  KEY `fk_Auto_Motore1_idx` (`Motore_idMotore`),
  KEY `fk_Auto_Telaio1_idx` (`Telaio_idTelaio`),
  KEY `fk_Auto_Possessore1_idx` (`Possessore_PIVA_CF`),
  KEY `fk_Auto_RegistroIN_OUT1_idx` (`RegistroIN_OUT_idRegistroIN_OUT`),
  CONSTRAINT `fk_Auto_Motore1` FOREIGN KEY (`Motore_idMotore`) REFERENCES `motore` (`idMotore`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Auto_Possessore1` FOREIGN KEY (`Possessore_PIVA_CF`) REFERENCES `possessore` (`PIVA_CF`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Auto_RegistroIN_OUT1` FOREIGN KEY (`RegistroIN_OUT_idRegistroIN_OUT`) REFERENCES `registroin_out` (`idRegistroIN_OUT`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Auto_Telaio1` FOREIGN KEY (`Telaio_idTelaio`) REFERENCES `telaio` (`idTelaio`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB;



CREATE TABLE `schedaprestazioni` (
  `idRegistroPersonale` int(11) NOT NULL AUTO_INCREMENT,
  `DataGiorno` date DEFAULT NULL,
  `OreLavorate` int(2) DEFAULT NULL,
  `TipoAttività` varchar(45) DEFAULT NULL,
  `Impiegato_CodiceIdentificativo` varchar(45) NOT NULL,
  PRIMARY KEY (`idRegistroPersonale`,`Impiegato_CodiceIdentificativo`),
  KEY `fk_SchedaPrestazioni_Impiegato1_idx` (`Impiegato_CodiceIdentificativo`),
  CONSTRAINT `fk_SchedaPrestazioni_Impiegato1` FOREIGN KEY (`Impiegato_CodiceIdentificativo`) REFERENCES `impiegato` (`CodiceIdentificativo`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB;

LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\sede.txt' INTO TABLE concessionariadef.sede FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (idSede, Denominazione, Via, Città, Provincia, Telefono, email, Padiglione, NumeroAuto);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\impiegato.txt' INTO TABLE  concessionariadef.impiegato FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (CodiceIdentificativo, PIVA_CF, Nome, Cognome, email, telefono, Via, Città, Provincia, Stato, Mansione, età, DataAssunzione, DataFineRapporto, Stipendio, Ferie, Sede_idSede);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\clienti.txt' INTO TABLE  concessionariadef.clienti FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (PIVA_CF, Nome, Cognome, email, telefono, Via, Città, Provincia, Stato);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\motore.txt' INTO TABLE  concessionariadef.motore FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (idMotore, Cilindrata, Alimentazione, DataCostruzione);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\telaio.txt' INTO TABLE  concessionariadef.telaio FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (idTelaio, DataCostruzione, Caratteristiche);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\possessore.txt' INTO TABLE  concessionariadef.possessore FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (PIVA_CF, Nome, Cognome, email, telefono, Via, Città, Provincia, Stato);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\registroIN_OUT.txt' INTO TABLE  concessionariadef.registroin_out FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (idRegistroIN_OUT, TipoInOut, DataRegistrazione, Sede_idSede, Clienti_PIVA_CF, Impiegato_CodiceIdentificativo, CodiceOperazione, Prezzo);
LOAD DATA LOCAL INFILE 'C:\\Users\\Benedetto Scala\\Desktop\\Concessionaria\\auto.txt' INTO TABLE  concessionariadef.auto FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' (idVeicolo, NumeroSerie, Chilometri, Anno, Colore, Accessori, Marca, Modello, Alimentazione, Targa, DestinazioneUso, Motore_idMotore, Telaio_idTelaio, Possessore_PIVA_CF, RegistroIN_OUT_idRegistroIN_OUT);
INSERT INTO `concessionariadef`.`schedaprestazioni` (`idRegistroPersonale`, `DataGiorno`, `OreLavorate`, `TipoAttività`, `Impiegato_CodiceIdentificativo`) VALUES ('1', '2018-01-09', '8', 'Revisione', '1');
INSERT INTO `concessionariadef`.`schedaprestazioni` (`idRegistroPersonale`, `DataGiorno`, `OreLavorate`, `TipoAttività`, `Impiegato_CodiceIdentificativo`) VALUES ('1', '2018-01-02', '4', 'Vendita', '3');
INSERT INTO `concessionariadef`.`schedaprestazioni` (`idRegistroPersonale`, `DataGiorno`, `OreLavorate`, `TipoAttività`, `Impiegato_CodiceIdentificativo`) VALUES ('1', '2017-02-20', '3', 'Vendita', '11');
INSERT INTO `concessionariadef`.`schedaprestazioni` (`idRegistroPersonale`, `DataGiorno`, `OreLavorate`, `TipoAttività`, `Impiegato_CodiceIdentificativo`) VALUES ('1', '2018-01-05', '6', 'Revisione', '113');
